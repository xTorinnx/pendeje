package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.PlanetDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class PlanetDAO implements CRUDOperation {

	public EntityManagerFactory emf;
	public EntityManager em;

	


	public PlanetDAO() {
		emf = Persistence.createEntityManagerFactory("default");
		em = emf.createEntityManager();
	}

	public void open() {
		if (!emf.isOpen() || !em.isOpen()) {
			emf = Persistence.createEntityManagerFactory("default");
			em = emf.createEntityManager();
		}
	}
	
	

	public EntityManager getEntityManager() {
		return emf.createEntityManager();
	}

	@Override
	public void create(Object o) {
		open();
		try {
			// Insert
			em.getTransaction().begin();
			em.persist(o);
			em.getTransaction().commit();

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (emf != null) {
				emf.close();
			}
			if (em != null) {
				em.close();
			}
		}

	}

	@Override
	public boolean delete(long id) {
		open();
		try {
			// Delete
			em.getTransaction().begin();
			em.remove(em.find(PlanetDTO.class, id));
			em.getTransaction().commit();
			return true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (emf != null) {
				emf.close();
			}
			if (em != null) {
				em.close();
			}
		}
		return false;
	}

	@Override
	public boolean update(long id, Object o) {
		open();
		try {
			// Update
			em.getTransaction().begin();
			PlanetDTO selectedPlanetDTO = em.find(PlanetDTO.class, id);
			PlanetDTO newData = (PlanetDTO) o;
			selectedPlanetDTO.setName(newData.getName());
			selectedPlanetDTO.setNumSatelites(newData.getNumSatelites());
			selectedPlanetDTO.setWeight(newData.getWeight());
			selectedPlanetDTO.setTemperature(newData.getTemperature());
			em.persist(selectedPlanetDTO);
			em.getTransaction().commit();
			return true;

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (emf != null) {
				emf.close();
			}
			if (em != null) {
				em.close();
			}
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public  ArrayList<PlanetDTO> findAll() {
		open();
		try {
			return (ArrayList<PlanetDTO>) em.createQuery("select u from PlanetDTO u").getResultList();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (emf != null) {
				emf.close();
			}
			if (em != null) {
				em.close();
			}
		}
		return new ArrayList<PlanetDTO>();
	}

	@Override
	public Object findOne(long id) {
		open();
		try {
			// Find
			PlanetDTO selectedPlanetDTO = em.find(PlanetDTO.class, id);
			return selectedPlanetDTO;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (emf != null) {
				emf.close();
			}
			if (em != null) {
				em.close();
			}
		}
		return null;
	}

}
