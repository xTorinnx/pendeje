package co.edu.unbosque.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "planet")
public class PlanetDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "name", nullable = false)
	private String name;
	@Column(name = "numSatelites", nullable = false)
	private long numSatelites;
	@Column(name = "weight", nullable = false)
	private long weight;
	@Column(name = "temperature", nullable = false)
	private long temperature;
	
	public PlanetDTO() {
		
	}

	public PlanetDTO(long id, String name, long numSatelites, long weight, long temperature) {
		super();
		this.id = id;
		this.name = name;
		this.numSatelites = numSatelites;
		this.weight = weight;
		this.temperature = temperature;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getNumSatelites() {
		return numSatelites;
	}

	public void setNumSatelites(long numSatelites) {
		this.numSatelites = numSatelites;
	}

	public long getWeight() {
		return weight;
	}

	public void setWeight(long weight) {
		this.weight = weight;
	}

	public long getTemperature() {
		return temperature;
	}

	public void setTemperature(long temperature) {
		this.temperature = temperature;
	}
	
}
