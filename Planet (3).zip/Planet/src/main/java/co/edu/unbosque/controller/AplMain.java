	package co.edu.unbosque.controller;


import co.edu.unbosque.model.PlanetDTO;
import co.edu.unbosque.model.persistence.PlanetDAO;

public class AplMain {
	
	public static void main(String[] args) {
		PlanetDAO us = new PlanetDAO();
		PlanetDTO u1= new PlanetDTO(1L,"admin", 1234L,2L,2L);
		us.create(u1);
		
		for (PlanetDTO u : us.findAll()) {
			System.out.println(u.getId()+"-"+u.getName()+"-"+u.getNumSatelites()+"-"+u.getWeight()+"-"+u.getTemperature());
		}	

	}

}
