package co.edu.unbosque.beans;

import java.util.ArrayList;
import java.util.List;
import org.primefaces.event.RowEditEvent;
import co.edu.unbosque.model.PlanetDTO;
import co.edu.unbosque.model.persistence.PlanetDAO;
import jakarta.annotation.ManagedBean;
import jakarta.enterprise.context.RequestScoped;


@ManagedBean
@RequestScoped
public class PlanetBean {
	private long id;
	private String name;
	private long numSatelites;
	private long Temperature;
	private long weight;
	private PlanetDAO pdao;
	List<PlanetDTO> planets;
	private PlanetDTO selectedPlanet;
	private ArrayList<PlanetDTO> planet;
	public PlanetBean() {
	
	
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getNumSatelites() {
		return numSatelites;
	}
	public void setNumSatelites(long numSatelites) {
		this.numSatelites = numSatelites;
	}
	public long getTemperature() {
		return Temperature;
	}
	public void setTemperature(long temperature) {
		Temperature = temperature;
	}
	public long getWeight() {
		return weight;
	}
	public void setWeight(long weight) {
		this.weight = weight;
	}
	public PlanetDAO getPdao() {
		return pdao;
	}
	public void setPdao(PlanetDAO pdao) {
		this.pdao = pdao;
	}
	public PlanetDTO getSelectedPlanet() {
		return selectedPlanet;
	}
	public void setSelectedPlanet(PlanetDTO selectedPlanet) {
		this.selectedPlanet = selectedPlanet;
	}
	public void deletePlanet() {
		this.pdao.delete(selectedPlanet.getId());
		this.planets.remove(selectedPlanet);
		this.selectedPlanet = null;
	}
	public void editListener(RowEditEvent event) {
		PlanetDTO planet = (PlanetDTO) event.getObject();
		pdao.update(getId(), planet);
	}
	public void addPlanet() {
		this.pdao.create(selectedPlanet);
		this.planets.add(selectedPlanet);
		this.selectedPlanet = null;
	}
	public void restartSelectedPlanet() {
		this.selectedPlanet = new PlanetDTO();
	}
}
